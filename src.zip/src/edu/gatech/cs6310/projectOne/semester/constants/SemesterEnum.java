package edu.gatech.cs6310.projectOne.semester.constants;

/**
 * Created by dawu on 2/10/16.
 */
public enum SemesterEnum {
    FALL(),
    SPRING(),
    SUMMER();

    SemesterEnum() {
    }
}
